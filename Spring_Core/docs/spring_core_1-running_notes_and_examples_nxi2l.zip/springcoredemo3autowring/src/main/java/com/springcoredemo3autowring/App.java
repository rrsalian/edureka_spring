package com.springcoredemo3autowring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
    	
    	Employee emp = context.getBean("employee", Employee.class);
    	emp.setEmpId("E100");
    	emp.setEmpName("Rajesh");
    	Department dept = context.getBean("dept", Department.class);
    	dept.setDeptId("D100");
    	dept.setDeptName("Finace dept");
    	Organization org = context.getBean("org", Organization.class);
    	org.setOrgId("o1");
    	org.setOrgName("ABC retail store");
    	
    	HeadUnit hu = context.getBean("hu", HeadUnit.class);
    	hu.setName("Product unit");
    	System.out.println(emp.getEmpId()+" "+emp.getDept().getDeptName()+" "+emp.getOrg().getOrgName()+" "+emp.getDept().getHeadUnit().getName());
    }
}
