package com.springcoredemo3autowring;

public class Department {
	private HeadUnit headUnit;
	
	public HeadUnit getHeadUnit() {
		return headUnit;
	}
	public Department(HeadUnit headUnit) {
		this.headUnit = headUnit;
	}
	
	private String deptId;
	private Organization org;
	
	
	public Organization getOrg() {
		return org;
	}
	public void setOrg(Organization org) {
		this.org = org;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	private String deptName;
	
	

}
