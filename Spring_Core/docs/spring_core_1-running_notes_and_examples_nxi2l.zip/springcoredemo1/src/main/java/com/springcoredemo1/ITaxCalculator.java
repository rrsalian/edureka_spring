package com.springcoredemo1;

public interface ITaxCalculator {
	
	public double calculateTax(double loanAmount);

}
