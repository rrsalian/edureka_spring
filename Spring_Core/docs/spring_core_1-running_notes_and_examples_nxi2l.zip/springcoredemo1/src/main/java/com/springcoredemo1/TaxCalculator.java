package com.springcoredemo1;

public class TaxCalculator implements ITaxCalculator {
	public double calculateTax(double loanAmount) {
		//logic for tax computation
		return loanAmount*0.1;
	}

}
