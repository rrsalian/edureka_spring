package com.springcoredemo1;

public class NewTaxCalculator implements ITaxCalculator {
	public double calculateTax(double loanAmount) {
		//logic for tax computation
		return loanAmount*0.15;
	}

}
