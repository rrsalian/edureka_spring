package com.springcoredemo1;

import java.io.FileInputStream;
import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args ) throws Exception
    {
        //TaxCalculator calculator = new TaxCalculator();
    	//object creation should not be taken from client
    	//IOC using spring
    	//create an object of ApplicationContext(spring container/factory)
    	//passing the xml configuration
    	ApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
    	
    	//asking the application context, give me the object/bean of taxcalculator
    	Properties props = new Properties();
    	props.load(new FileInputStream("beanname.properties"));
    	String beanName = props.getProperty("beanname");
    	ITaxCalculator calculator = context.getBean(beanName,ITaxCalculator.class);
    	double taxValue = calculator.calculateTax(2000000);
    	System.out.println(taxValue);
    }
}
