package com.springbeanscopes;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class AppConfig {
	
	//the bean id becomes emp and not method name "employee"
	//now the bean scope is changed to prototype
	@Bean("emp")
	//@Scope("prototype")
	//by default is singleton and eager loading
	@Lazy //this annotation will specify the bean loading is lazy
	//this will not get executed during the application context creation
	public Employee employee() {
		System.out.println("in employee bean definition");
		Employee emp = new Employee();
		//injecting department bean in this property
		//emp.setDept(department());
		return emp;
	}
	
	//this bean is of type Department with bean id department(by default method name is bean id)
	//scope is singleton
	@Bean
	public Department department() {
		return new Department();
	}
	
	//this bean is of type Department with bean id dept
	@Bean
	public Department dept() {
		return new Department();
	}

}
