package com.springbeanscopes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class App 
{
    public static void main( String[] args )
    {
    	//during the time of application context creation, the eager loading beans are created
    	ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
    	System.out.println("context is created");
    	//during context.getBean @lazy bean is created
        Employee emp = context.getBean("emp",Employee.class);
        //System.out.println(emp);
        //in prototype scope, a new object or bean gets created every time when context.getBean is called
        /*emp = context.getBean("emp",Employee.class);
        System.out.println(emp);
        emp = context.getBean("emp",Employee.class);
        System.out.println(emp);*/
        
        
    }
}
