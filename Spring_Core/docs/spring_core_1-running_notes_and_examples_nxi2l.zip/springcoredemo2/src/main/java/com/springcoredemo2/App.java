package com.springcoredemo2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
    	
    	Employee emp = context.getBean("emp",Employee.class);
    	emp.setEmpId("E100");
    	emp.setEmpName("Rajesh");
    	
    	Department dept = context.getBean("department", Department.class);
    	//dept.setDeptId("D100");
    	//dept.setDeptName("Finance dept");
    	
    	Department dept1 = context.getBean("department1", Department.class);
    	//dept1.setDeptId("D101");
    	//dept1.setDeptName("IT dept");
    	
    	Organization org = context.getBean("organization",Organization.class);
    	org.setOrgId("o100");
    	org.setOrgName("ABC Brand");
    	
    	//dependency injection
    	//one object is passed to other object using setter method of the other object
    	//dept object is passed to emp object using setter method of emp object
    	//emp.setDept(dept);//employee E100, Rajesh is associated with department D100, finance dept
    	//System.out.println(emp.getEmpName());
    	//System.out.println(dept);
    	//here dependency injection is not happening--so it is giving null
    	System.out.println(emp.getEmpName()+" "+emp.getDept().getDeptName()+" "+emp.getOrg().getOrgName()+" "+emp.getDept().getHeadUnit().getUnitName());
    }
}
