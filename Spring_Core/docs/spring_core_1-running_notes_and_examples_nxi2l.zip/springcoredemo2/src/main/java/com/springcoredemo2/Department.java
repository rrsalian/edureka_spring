package com.springcoredemo2;

public class Department {
	
	
	private String deptId;
	private String deptName;
	private HeadUnit headUnit;
	
	
    //headunit object is injected through constructor
	public Department(HeadUnit headUnit) {
		this.headUnit = headUnit;
	}
	
	public HeadUnit getHeadUnit() {
		return headUnit;
	}
	
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	

}
