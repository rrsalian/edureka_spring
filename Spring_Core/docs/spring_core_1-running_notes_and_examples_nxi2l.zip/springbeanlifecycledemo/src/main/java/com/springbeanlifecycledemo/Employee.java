package com.springbeanlifecycledemo;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Employee implements InitializingBean,DisposableBean {
	
	private String empId;
	private String empName;
	
	public Employee() {
		//initialize employee object property values
		System.out.println("in employee constructor "+dept1);
	}
	
	/*@PostConstruct
	public void afterConstruct() {
		//initialize employee dependent object property values
		System.out.println("in post construct "+dept1);
	}
	
	@PreDestroy
	public void beforeDestroy() {
		//close any db connections or file connectioms before bean gets destroyed
		//initialize employee dependent object property values
		System.out.println("in pre destroy ");
	}*/
	
	@Autowired
	@Qualifier("dept")
	//this will match the property type with the bean class type in the configuration
	private Department dept1;
	
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Department getDept1() {
		return dept1;
	}
	public void setDept(Department dept1) {
		System.out.println("in set department");
		this.dept1 = dept1;
	}
	
	//this is equal to @PreDestroy
	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("before bean destroy");
	}
	
	
	//this is equal to @PostConstruct
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("post construct "+dept1);
		
	}
	
	
	

}
