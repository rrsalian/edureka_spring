package com.springbeanlifecycledemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
	
	//the bean id becomes emp and not method name "employee"
	@Bean("emp")
	public Employee employee() {
		Employee emp = new Employee();
		//injecting department bean in this property
		//emp.setDept(department());
		return emp;
	}
	
	//this bean is of type Department with bean id department(by default method name is bean id)
	@Bean
	public Department department() {
		return new Department();
	}
	
	//this bean is of type Department with bean id dept
	@Bean
	public Department dept() {
		return new Department();
	}

}
