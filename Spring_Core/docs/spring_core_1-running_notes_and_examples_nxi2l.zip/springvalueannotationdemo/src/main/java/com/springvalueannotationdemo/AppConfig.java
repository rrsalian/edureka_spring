package com.springvalueannotationdemo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
//@PropertySource refers to the property file name
@PropertySource("classpath:db.properties")
public class AppConfig {
	
	//@Value will inject the value of the key datasource.url from db.properties file into
	//variable host
	@Value("${datasource.url}")
	private String host;
	
	//@Value will inject the value of the key datasource.userId from db.properties file into
	//variable userId
	@Value("${datasource.userId}")
	private String userId;
	
	@Bean
	public DatabaseConnector databaseConnector() {
		DatabaseConnector databaseconnector = new DatabaseConnector();
		databaseconnector.setHost(host);
		databaseconnector.setUserId(userId);
		return databaseconnector;
	}

}
