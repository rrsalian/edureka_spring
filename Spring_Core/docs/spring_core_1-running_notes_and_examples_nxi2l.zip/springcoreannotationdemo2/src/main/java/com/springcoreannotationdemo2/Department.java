package com.springcoreannotationdemo2;

import org.springframework.stereotype.Component;


//bean id is dept
@Component("dept")
public class Department {
	
	private String deptId;
	private String deptName;
	
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	

}
