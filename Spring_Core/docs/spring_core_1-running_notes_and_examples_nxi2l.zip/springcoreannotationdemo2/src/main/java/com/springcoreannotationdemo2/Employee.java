package com.springcoreannotationdemo2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("emp")
public class Employee {
	
	private String empId;
	private String empName;
	
	@Autowired
	@Qualifier("dept")
	//this will match the property type with the bean class type in the configuration
	private Department dept1;
	
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Department getDept1() {
		return dept1;
	}
	public void setDept(Department dept1) {
		this.dept1 = dept1;
	}
	
	
	

}
