package com.springcoreannotationdemo2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class AppConfig {
	
	//spring container will give preference to @Bean and execute even @Component is present for same class
	@Bean
	public Employee employee() {
		System.out.println("in employee bean");
		return new Employee();
	}

}
